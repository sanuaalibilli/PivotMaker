import os
from core import CommonUtils
from core import CustomLogger
from core import Recon_Processor 

#from core_new.CustomLogger import getCustomLogger


logger = CustomLogger.getCustomLogger("Recon_Main")
inputsFile = open("Mappings.txt", "r")

# READ THE INPUTS FILE AND CREATE RECON_DETAIL OBJECTS
filesToProcess = []
formatter = True
while True:
    line = inputsFile.readline()
    strLine = line.strip()
    # print("Line# is ",i," : Line is ",str)
    # BREAK THE LOOP ON END OF FILE
    if not line: 
        break
    
    fileObj, message =  CommonUtils.createFileInfo(strLine)
    if not(None == fileObj):
        filesToProcess.append(fileObj)
    else:
        logger.error(message)
        formatter = False
    
    if not(formatter):
        break
    
if(formatter):     
    outFileType = CommonUtils.getConfigProperty("INPUTS", "OUTPUT_FILE_TYPE")
    outFileDir = CommonUtils.getConfigProperty("INPUTS", "OUTPUT_DIRECTORY")
    outFileName = ""
    if("SINGLE" == outFileType.strip()):
        outFileName = os.path.join((outFileDir), (CommonUtils.parseFileLink(CommonUtils.getConfigProperty("INPUTS", "SINGLE_OUTFILE_NAME"), CommonUtils.getConfigProperty("INPUTS", "BUSINESS_DATE"), CommonUtils.getConfigProperty("INPUTS", "BUSINESS_DATE_PARAM"))))
        # headerOn = True
        logger.debug("Using Ouput File : " + outFileName)
        # CREATE OUTPUTFILE DIRECTORY STRUCTURE IF NOT PRESENT
        if not (os.path.exists(outFileDir)):
            logger.debug("Output Directory Does not Exist : " + outFileDir)
            logger.debug("Creating Output Directory : " + outFileDir)
            os.makedirs(outFileDir)
# OPEN OUT FILE
        openOutfile = open(outFileName, "a")
        openOutfile.write(CommonUtils.getConfigProperty("INPUTS", "OUTPUT_FILE_HEADER") + "\n")
        openOutfile.close()
        
    for fileDetail in filesToProcess:
        Recon_Processor.processfile(fileDetail)
