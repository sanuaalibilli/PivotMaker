from core import CustomLogger

logger = CustomLogger.getCustomLogger("Recon_Detail")
class File_Info:

    #===========================================================================
    __FileName = ""
    __DataSetName = ""
    __KeyColumnNameIndices = {}
    #===========================================================================
    
    def __init__(self, FileName, DataSetName, KeyColNames, KeyColIndices):
        self.__FileName = FileName
        self.__DataSetName = DataSetName
        self.__KeyColumnNameIndices = self.createKeyColDictionary(KeyColNames,KeyColIndices)

    def get_file_name(self):
        return self.__FileName

    def get_data_set_name(self):
        return self.__DataSetName


    def get_key_column_name_indices(self):
        return self.__KeyColumnNameIndices


    def get_key_col_indices(self):
        return self.__KeyColIndices


    def set_file_name(self, value):
        self.__FileName = value


    def set_data_set_name(self, value):
        self.__DataSetName = value


    def set_key_column_name_indices(self, value):
        self.__KeyColumnNameIndices = value


    def set_key_col_indices(self, value):
        self.__KeyColIndices = value




    def createKeyColDictionary(self,KeyColNames,KeyColIndices):
        keyDict = {}
        i = 0
        for key in KeyColNames:
            keyDict.setdefault(key, KeyColIndices[i])
            i=i+1
        logger.debug("Key Column Name Index Mapping is " + str(keyDict))
        return keyDict
    
    FileName = property(get_file_name, set_file_name, None, None)
    DataSetName = property(get_data_set_name, set_data_set_name, None, None)
    KeyColumnNameIndices = property(get_key_column_name_indices, set_key_column_name_indices, None, None)
    KeyColIndices = property(get_key_col_indices, set_key_col_indices, None, None)
            
    
