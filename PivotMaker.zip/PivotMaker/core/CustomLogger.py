import logging
import configparser



def getLoggingConfigProperty(section_name, key_name):    
    config = configparser.RawConfigParser()
    config.read('config.properties')
    #logger.debug("CONFIG PROPERTY: " + section_name + " : " + key_name + " : " + config.get(section_name, key_name))
    return config.get(section_name, key_name)

#===============================================================================
# Adding Logging
# Create a custom logger

# Create handlers

# c_handler.setLevel(logging.DEBUG)
# f_handler.setLevel(logging.ERROR)
# Create formatters and add it to handlers



# Add handlers to the logger

# 
#===============================================================================


def getCustomLogger(name):
    logger = logging.getLogger(name)
    logger.setLevel(getLoggingConfigProperty("LOGGING", "LOGLEVEL"))
    c_handler = logging.StreamHandler()
    f_handler = logging.FileHandler(getLoggingConfigProperty("LOGGING", "LOGFILE"), 'w')
    c_format = logging.Formatter(getLoggingConfigProperty("LOGGING", "CONSOLELOGFORMAT"))
    f_format = logging.Formatter(getLoggingConfigProperty("LOGGING", "FILELOGFORMAT"))
    logger.addHandler(c_handler)
    logger.addHandler(f_handler)
    c_handler.setFormatter(c_format)
    f_handler.setFormatter(f_format)
    return logger