from _datetime import datetime
import configparser
import glob
import gzip
import os.path
import shutil
from core import CustomLogger
import pandas as pd
from core import Recon_File_Info

#===============================================================================
# Adding Logging
# Create a custom logger
# logger = logging.getLogger("CommonUtil.py")
# logger.setLevel(getConfigProperty("LOGGING","LOGLEVEL"))
# Create handlers
# c_handler = logging.StreamHandler()
# f_handler = logging.FileHandler('diagnostic.log','a')
# c_handler.setLevel(logging.DEBUG)
# f_handler.setLevel(logging.ERROR)
# Create formatters and add it to handlers
# c_format = logging.Formatter('%(asctime)s - %(threadName)s - %(name)s - %(levelname)s - %(message)s')
# f_format = logging.Formatter('%(asctime)s - %(threadName)s - %(name)s - %(levelname)s - %(message)s')
# c_handler.setFormatter(c_format)
# f_handler.setFormatter(f_format)
# Add handlers to the logger
# logger.addHandler(c_handler)
# logger.addHandler(f_handler)
# 
#===============================================================================
logger = CustomLogger.getCustomLogger("CommonUtils")


def getAliases():    
    aliasFile = open("Aliases.txt", "r")
    aliaslines = aliasFile.readlines()
    aliasFile.close()
    return aliaslines


def createFileInfo(strLine):    
    message = ""     
    FileName = parseFileLink(strLine.split("|")[0], getConfigProperty("INPUTS", "BUSINESS_DATE"), getConfigProperty("INPUTS", "BUSINESS_DATE_PARAM"))
    DataSetName = strLine.split("|")[1]
    KeyColumnNames = (strLine.split("|")[2]).split(",")
    KeyColumnIndices = (strLine.split("|")[3]).split(",")
    logger.debug("File Line: %s , %s, %s, %s",FileName, DataSetName, KeyColumnNames, KeyColumnIndices)
    if(len(KeyColumnNames) == len(KeyColumnIndices)):
        fileInfo = Recon_File_Info.File_Info(FileName, DataSetName, KeyColumnNames, KeyColumnIndices)
        message = ("Mappings File is Correct. Count of KeyColumnNames (%s) and KeyColumnIndices (%s) Match..",len(KeyColumnNames),len(KeyColumnIndices))
        return fileInfo, message
    else:
        message = ("Mappings File is not correct. Count of KeyColumnNames (%s) and KeyColumnIndices (%s) doesnot match..",len(KeyColumnNames),len(KeyColumnIndices))
        logger.error("Mappings File is not correct. Count of KeyColumnNames (%s) and KeyColumnIndices (%s) doesnot match..",len(KeyColumnNames),len(KeyColumnIndices))
        return None, message
    


def getNowDate():
    return (datetime.now().strftime('%Y%m%d_%H%M%S'))


def getPostDate(daysfuture):
    return (datetime.now())


def getConfigProperty(section_name, key_name):    
    config = configparser.RawConfigParser()
    config.read('config.properties')
    logger.debug("CONFIG PROPERTY: " + section_name + " : " + key_name + " : " + config.get(section_name, key_name))
    return config.get(section_name, key_name)


def getInputFiles(filePath):
    infile = open(filePath, 'r')
    return infile.readlines()


def getColumnValues(data, keycolumnNameIndices, nonkeyColNameIndices):
    keynamevalues = {}
    nonKeynameValues = {}
    logger.debug("Before KeyColNameVals is %s",dict(keycolumnNameIndices))
    logger.debug("Before NonKeyColNameVals is %s",dict(nonkeyColNameIndices))
    i = 0
    for val in data.split("|"):
        logger.debug("keycolumnNameIndices.keys() is %s",keycolumnNameIndices.keys())
        if str(i) in keycolumnNameIndices.keys():
            if not None:#logger.info("index is %s and keycolName is %s and Col Val is %s",i,keycolumnNameIndices.get(str(i)),val.strip())
                keynamevalues.setdefault(keycolumnNameIndices.get(str(i)), val.strip())
        else:
            if not None:#logger.info("index is %s and NonkeycolName is %s and Col Val is %s",i,nonkeyColNameIndices.get(str(i)),val.strip())
                nonKeynameValues.setdefault(nonkeyColNameIndices.get((i)), val.strip())
        
        i = i + 1
    logger.debug("1KeyColNameVals is %s",(keynamevalues))
    logger.debug("1NonKeyColNameVals is %s",(nonKeynameValues))
    return keynamevalues, nonKeynameValues
           

def parseFileLinks(fileLinks, busDate, busDateParam):
    parsedLinks = []
    for link in fileLinks :
        parsedLinks.append(link.strip().replace(busDateParam, busDate))
    return parsedLinks


def parseFileLink(fileLink, busDate, busDateParam):
    return (fileLink.strip().replace(busDateParam, busDate))     


def setAliases(aliases, out_row):
    temp = out_row
    for index, row in pd.DataFrame(aliases).iterrows():
        if row['ColumnName'] in temp:
            # print(row['ColumnName'],row['Alias'])
            temp = temp.replace(row['ColumnName'], row['Alias'])
    return temp

  
def mapColumnandRow(columns, row):
    mappedLines = []
    columnz = columns.split("|")
    counter = 0
    for li in row.split("|"):
        # print(columnz[counter] + "|" + li.strip())
        mappedLines.append(columnz[counter] + "|" + li.strip())
        counter = counter + 1
    return mappedLines


def iskeyColumn(keycolumnNames, data):
    status = False
    for colName in keycolumnNames.split(","):
        if colName in data:
            status = True
            break
    return status


def gzipOldFiles(dirPath):
    files = glob.glob(os.path.join(dirPath + "*.dat"))
    logger.info(files)
    filecount = len(files) 
    logger.debug(filecount, " Old Files Present in Output Directory")
    if (len(files) > 0):
        for f in files:
            with open(f, 'rb') as f_in, gzip.open(f + ".gz", 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
            f_in.close()
            f_out.close()
            logger.debug("Deleting File : " + f)
            os.remove(f)
