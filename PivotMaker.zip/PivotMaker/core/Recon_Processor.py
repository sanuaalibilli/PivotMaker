import os
import time
from core import CommonUtils
from core import CustomLogger



#===============================================================================
# Adding Logging
# Create a custom logger
# logger = logging.getLogger("Recon_Processor.py")
# logger.setLevel(getConfigProperty("LOGGING","LOGLEVEL"))
# Create handlers
# c_handler = logging.StreamHandler()
# f_handler = logging.FileHandler('diagnostic.log','a')
# c_handler.setLevel(logging.DEBUG)
# f_handler.setLevel(logging.ERROR)
# Create formatters and add it to handlers
# c_format = logging.Formatter('%(asctime)s - %(threadName)s - %(name)s - %(levelname)s - %(message)s')
# f_format = logging.Formatter('%(asctime)s - %(threadName)s - %(name)s - %(levelname)s - %(message)s')
# c_handler.setFormatter(c_format)
# f_handler.setFormatter(f_format)
# Add handlers to the logger
# logger.addHandler(c_handler)
# logger.addHandler(f_handler)
# 
#===============================================================================
logger = CustomLogger.getCustomLogger("Recon_Processor")
KeyColumnNameIndices = {}               #key Index - Value ColName
NonKeyColumnNameIndices = {}            #key Index - Value ColName
AliasedNonKeyColumnNameIndices = {}     #key Index - Value ColName
AliasedKeyColumnNameIndices = {}        #key Index - Value ColName
AliasesDict = {}
AliasStatus = False
inv_KeyColumnNameIndices = {}
inv_NonKeyColumnNameIndices = {}
inv_AliasedNonKeyColumnNameIndices = {}
inv_AliasedKeyColumnNameIndices = {}

    
def processfile(fileDetail):
    logger.info("*********************************************************************************************")
    logger.info("%s : Processing File %s", time.asctime(time.localtime(time.time())), fileDetail.FileName)
    # startTime = int(round(time.time() * 1000))
    # logger.info("Start Time is %s",startTime)
    
    starttime = time.time() * 1000
    logger.debug("Setting File Start Time : %s", starttime)
    #if(len(__KeyColumnNameIndices)<1):
    global KeyColumnNameIndices
    global NonKeyColumnNameIndices
    global AliasedKeyColumnNameIndices
    global AliasedNonKeyColumnNameIndices
    global AliasStatus
    global inv_KeyColumnNameIndices
    global inv_NonKeyColumnNameIndices
    global inv_AliasedNonKeyColumnNameIndices
    global inv_AliasedKeyColumnNameIndices
    
    KeyColumnNameIndices = (fileDetail.KeyColumnNameIndices)
    inv_KeyColumnNameIndices = {v: k for k, v in KeyColumnNameIndices.items()}
    logger.debug("Inversed KeyCol Name Indices "+str(inv_KeyColumnNameIndices))
    actualFileName = fileDetail.FileName
    
    outFileType = CommonUtils.getConfigProperty("INPUTS", "OUTPUT_FILE_TYPE")
    outFileDir = CommonUtils.getConfigProperty("INPUTS", "OUTPUT_DIRECTORY")
    outFileName = ""
    if("SINGLE" == outFileType.strip()):
        outFileName = os.path.join((outFileDir), (CommonUtils.parseFileLink(CommonUtils.getConfigProperty("INPUTS", "SINGLE_OUTFILE_NAME"), CommonUtils.getConfigProperty("INPUTS", "BUSINESS_DATE"), CommonUtils.getConfigProperty("INPUTS", "BUSINESS_DATE_PARAM"))))
        # headerOn = True
    else:
        path, name = os.path.split(actualFileName)
        outFileNm = CommonUtils.getConfigProperty("INPUTS", "OUTPUT_FILE_PREFIX") + "_" + name.strip()
        outFileName = os.path.join(outFileDir, outFileNm)
    logger.debug("Using Ouput File : " + outFileName)
    # CREATE OUTPUTFILE DIRECTORY STRUCTURE IF NOT PRESENT
    if not (os.path.exists(outFileDir)):
        logger.debug("Output Directory Does not Exist : " + outFileDir)
        logger.debug("Creating Output Directory : " + outFileDir)
        os.makedirs(outFileDir)
    # OPEN OUT FILE
    logger.debug("Outfile Name for this file is %s", outFileName)
    
    if("True" == CommonUtils.getConfigProperty("INPUTS", "SET_ALIAS")):
        AliasStatus = True
    else:
        AliasStatus = False
    logger.info("Alias Setting for this file is %s", AliasStatus)
    logger.info("OutFile Type for this file is %s", outFileType)
    
    #CommonOutLine = getCommonOutLine(fileDetail, AliasStatus)
    CommonOutLine = fileDetail.FileName+"|"+fileDetail.DataSetName 
    logger.debug("CommonOutLine for this file is %s", CommonOutLine)
    logger.debug("Opening Input File %s for Reading.", actualFileName)
    openInputFile = open(actualFileName, 'r')
    logger.debug("Opening Output File %s for Writing.", outFileName)
    
    openOutfile = open(outFileName, "a")
    if not("SINGLE" == outFileType.strip()):
        openOutfile.write(CommonUtils.getConfigProperty("INPUTS", "OUTPUT_FILE_HEADER") + "\n")
    
    i = 0
    while True:
        i = i + 1
        line = openInputFile.readline()
        strLine = line.strip()
        # print("Line# is ",i," : Line is ",str)
        # BREAK THE LOOP ON END OF FILE
        if not line: 
            break
        
        # SKIPPING HEADER LINE IN FILE
        if strLine.startswith("HDR"):
            continue    
        
        # SKIPPING FOOTER LINE IN FILE
        if strLine.startswith("TRL"):
            continue   
        
        # this line is the column names from the input file
        if (i == 2):
            columns = strLine 
            processcolumns(columns.split("|"))
            logger.debug("Identified Columns In this File are %s",columns.split("|"))
        else:
            # logger.info("Printing Row Data: %s",strLine)
            #keyColumnValues, nonKeyColumnValues = CommonUtils.getKeyColumnValues(strLine, KeyColumnNameIndices)
            # logger.info("KeyColum Values is %s",keyColumnValues)
            keyColNameValues = {}
            nonKeyColNameValues = {}
            if not(AliasStatus):
                #global inv_KeyColumnNameIndices
                #global inv_NonKeyColumnNameIndices
                logger.debug("Inversed KeyColumnNameIndices are %s",inv_KeyColumnNameIndices)
                logger.debug("Inversed NonKeyColumnNameIndices are %s",inv_NonKeyColumnNameIndices)  
                keyColNameValues,nonKeyColNameValues = CommonUtils.getColumnValues(strLine,inv_KeyColumnNameIndices,inv_NonKeyColumnNameIndices)                
            else:
                #global inv_AliasedKeyColumnNameIndices
                #global inv_AliasedKeyColumnNameIndices
                logger.debug("Inversed AliasedKeyColumnNameIndices are %s",inv_AliasedKeyColumnNameIndices)
                logger.debug("Inversed AliasedNonKeyColumnNameIndices are %s",inv_AliasedKeyColumnNameIndices)              
                keyColNameValues,nonKeyColNameValues = CommonUtils.getColumnValues(strLine,inv_AliasedKeyColumnNameIndices,inv_AliasedNonKeyColumnNameIndices)
            
            logger.debug("1KeyColNameVakues is ", (keyColNameValues))
            logger.debug("1NonKeyColNameValues is ",(nonKeyColNameValues))
            FinalCommonOutLine = CommonOutLine+"|"+str(",".join(keyColNameValues.keys()))+"|"+str(",".join(keyColNameValues.values()).strip('"'))
            logger.debug("Final Common Line is %s",FinalCommonOutLine)
            logger.debug("Before Final Print %s",nonKeyColNameValues.keys())
            for rec in nonKeyColNameValues.keys():
                #finalReord=""
                logger.debug("Rec is %s and vlaue(rec) is %s",rec,nonKeyColNameValues.get(rec))
                finalRecord = FinalCommonOutLine+"|"+rec+"|"+nonKeyColNameValues.get(rec).strip('"')
                logger.debug("Final Write Records is %s",finalRecord)
                openOutfile.write(finalRecord+"\n")                      
                                       
            #===================================================================
            # else:
            #     logger.debug("Size : %s ------NonKeyColumns are %s", len(fileDetail.getNonKeyColumnNames()), fileDetail.getNonKeyColumnNames())
            #     logger.debug("Size : %s NonKeyColumnsValues are %s", len(nonKeyColumnValues), nonKeyColumnValues)  
            #     if len(nonKeyColumnValues) == len(fileDetail.getNonKeyColumnNames()):
            #     # index = 0
            #         for x in list(range(len(nonKeyColumnValues))):
            #             commonString = str(fileDetail.getCommonOutLine())
            #             logger.debug("CommonString is %s", commonString)
            #             NonKeyColName = fileDetail.getNonKeyColumnNames()[x]
            #             NonKeyColVal = nonKeyColumnValues[x].strip()
            #             openOutfile.write("|".join([commonString, ",".join(keyColumnValues), NonKeyColName, NonKeyColVal]) + "\n")
            #         # index = index+1
            #===================================================================
    
    openInputFile.close()
    openOutfile.close()
    endTime= (time.time() * 1000)
    logger.debug("Setting File End Time : %s", endTime)
    logger.info("%s File Processing Time is %s seconds", time.asctime(time.localtime(time.time())),(endTime-starttime) / 1000)
    
    return True


def processcolumns(columns):
    global AliasStatus
    global KeyColumnNameIndices
    #NonKeyColumnsIndices
    #AliasedNonKeyColumnIndices
    frameNonKeyColumnsIndices(columns)
    if(AliasStatus):        
        frameAliasedNonKeyColumnIndices()
        if(len(AliasedKeyColumnNameIndices) < 1):
            frameAliasedKeyColumnIndices(KeyColumnNameIndices)
        
    

       
def getCommonOutLine(fileDetail,alias):
    commonline = ""
    if not(alias):
        commonline = "|".join({fileDetail.FileName , fileDetail.DataSetName })        
        #commonline = fileDetail.FileName + "|" + fileDetail.DataSetName + "|" + ",".join((list(fileDetail.KeyColumnNameIndices.keys())))
        logger.debug("Aliasing is  NOT TRUEEEEEEEEEEEEEEEEEEEEEEEEEEEEE: %s",commonline)
    else:
        if(len(AliasedKeyColumnNameIndices) < 1):
            frameAliasedKeyColumnIndices(fileDetail.KeyColumnNameIndices)
            commonline = fileDetail.FileName + "|" + fileDetail.DataSetName + "|" + ",".join(list(AliasedKeyColumnNameIndices.keys()))
            logger.debug("Aliasing is  TRUEEEEEEEEEEEEEEEEEEEEEEEEEEEEE: %s",commonline)
    return commonline

def frameAliasedKeyColumnIndices(KeyColumnNameIndices):
    global AliasesDict
    global AliasedKeyColumnNameIndices
    global inv_AliasedKeyColumnNameIndices
    logger.debug("KeyColumnNameIndices is %s",KeyColumnNameIndices)
    if(len(AliasesDict) < 1):
        frameAliasesDict()
    for val in KeyColumnNameIndices.keys():
        if val in AliasesDict.keys():
            AliasedKeyColumnNameIndices.setdefault(AliasesDict.get(val),KeyColumnNameIndices.get(val))
        else:
            AliasedKeyColumnNameIndices.setdefault(val,KeyColumnNameIndices.get(val))
    inv_AliasedKeyColumnNameIndices = {v: k for k, v in AliasedKeyColumnNameIndices.items()}
    logger.info("AliasedKeyColumnNameIndices framed %s",AliasedKeyColumnNameIndices)
    logger.info("Inversed AliasedKeyColumnNameIndices framed %s",inv_AliasedKeyColumnNameIndices)
    
    
def frameAliasesDict():
    global AliasesDict
    for val in CommonUtils.getAliases():
        AliasesDict.setdefault(val.strip().split(",")[0], val.strip().split(",")[1])
    logger.info("Aliases Framed : %s",AliasesDict)


def frameNonKeyColumnsIndices(columns):
    global NonKeyColumnNameIndices
    global KeyColumnNameIndices
    global inv_NonKeyColumnNameIndices
    x =0
    for val in columns:
        if not val in KeyColumnNameIndices.keys():
            NonKeyColumnNameIndices.setdefault(val,x)
        x = x+1
    inv_NonKeyColumnNameIndices = {v: k for k, v in NonKeyColumnNameIndices.items()}
    logger.info("NonKeyColumnNameIndices are %s",NonKeyColumnNameIndices)
    logger.info("Inversed NonKeyColumnNameIndices are %s",inv_NonKeyColumnNameIndices)
    
def frameAliasedNonKeyColumnIndices():
    global NonKeyColumnNameIndices
    global AliasedNonKeyColumnNameIndices
    global inv_AliasedNonKeyColumnNameIndices
    a=0
    for val in NonKeyColumnNameIndices.keys():
        if val in AliasesDict.keys():
            AliasedNonKeyColumnNameIndices.setdefault(AliasesDict.get(val),NonKeyColumnNameIndices.get(val))
        else:
            AliasedNonKeyColumnNameIndices.setdefault(val,NonKeyColumnNameIndices.get(val))
        a = a+1
    inv_AliasedNonKeyColumnNameIndices = {v: k for k, v in AliasedNonKeyColumnNameIndices.items()}
    logger.info("AliasedNonKeyColumnNameIndices are %s",AliasedNonKeyColumnNameIndices)
    logger.info("Inversed AliasedNonKeyColumnNameIndices are %s",inv_AliasedNonKeyColumnNameIndices)
          
